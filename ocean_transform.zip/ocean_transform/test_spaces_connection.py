#!/usr/bin/env python3
"""
Simple test script to verify DigitalOcean Spaces connection.
"""

import boto3
from botocore.config import Config

def test_connection():
    """Test connection to DigitalOcean Spaces and list directories."""
    
    # Configuration
    bucket = "historical-db-1min"
    base_prefix = "raw/parquet_data"  # Base prefix in your bucket
    region = "blr1"
    endpoint_url = "https://blr1.digitaloceanspaces.com"
    access_key = "DO00CDX8Z7BFTQJ9W2AZ"
    secret_key = "kR159s1x7Xjfd6RhVIyw8X34UGLIFKSzP7/0fG6Yt9I"
    
    print("=" * 80)
    print("DIGITALOCEAN SPACES CONNECTION TEST")
    print("=" * 80)
    print(f"Bucket: {bucket}")
    print(f"Base Prefix: {base_prefix}")
    print(f"Region: {region}")
    print(f"Endpoint: {endpoint_url}")
    print("=" * 80)
    
    try:
        # Create S3 client
        boto_config = Config(
            signature_version="s3v4",
            s3={"addressing_style": "virtual"},
            retries={"max_attempts": 5, "mode": "adaptive"},
        )
        
        client = boto3.client(
            "s3",
            region_name=region,
            endpoint_url=endpoint_url,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            config=boto_config,
        )
        
        print("\n✅ Client created successfully!")
        
        # List top-level directories (folders) under base_prefix
        print(f"\nListing directories under '{base_prefix}'...")
        paginator = client.get_paginator("list_objects_v2")
        directories = []
        
        # Ensure base_prefix ends with /
        prefix = base_prefix if base_prefix.endswith("/") else base_prefix + "/"
        
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix, Delimiter="/"):
            directories.extend(
                common["Prefix"] for common in page.get("CommonPrefixes", [])
            )
        
        print(f"\n✅ Found {len(directories)} top-level directories:")
        for directory in sorted(directories):
            print(f"  - {directory}")
        
        # Test reading a specific directory structure
        print("\n" + "=" * 80)
        print("Testing directory structure for NIFTY...")
        print("=" * 80)
        
        base = base_prefix if base_prefix.endswith("/") else base_prefix + "/"
        for data_type in ["index", "cash", "futures", "option", "options"]:
            prefix = f"{base}{data_type}/"
            response = client.list_objects_v2(Bucket=bucket, Prefix=prefix, MaxKeys=1)
            if response.get("KeyCount", 0) > 0:
                print(f"✅ Found: {prefix}")
                
                # List subdirectories
                subdirs = []
                for page in paginator.paginate(Bucket=bucket, Prefix=prefix, Delimiter="/"):
                    subdirs.extend(
                        common["Prefix"] for common in page.get("CommonPrefixes", [])
                    )
                
                for subdir in sorted(subdirs)[:5]:  # Show first 5
                    print(f"    - {subdir}")
                if len(subdirs) > 5:
                    print(f"    ... and {len(subdirs) - 5} more")
            else:
                print(f"❌ Not found: {prefix}")
        
        print("\n" + "=" * 80)
        print("CONNECTION TEST SUCCESSFUL!")
        print("=" * 80)
        print("\nYou can now run the transformation script:")
        print("  python transform_official_nautilus.py \\")
        print("      --bucket historical-db-1min \\")
        print("      --base-prefix raw/parquet_data \\")
        print("      --symbols NIFTY BANKNIFTY \\")
        print("      --start-date 2024-01-02 \\")
        print("      --end-date 2024-01-05")
        print("\n(Note: base-prefix is now default, you can omit it)")
        print("=" * 80)
        
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    test_connection()

