#################################################################################### importing libraries
from datetime import datetime
import pandas as pd
import numpy as np
import traceback
import logging
import config
import sys
import os
import re

pd.options.mode.chained_assignment = None

LOG_FILE_PATH = os.path.join(config.LOG_FILE_FOLDER, datetime.now().strftime("%d%m%Y, %H%M%S.%f")+".log")
logging.basicConfig(filename=LOG_FILE_PATH, format='%(asctime)s [%(levelname)s] [%(name)s] [%(threadName)s]: %(message)s', level=logging.DEBUG)

def handle_exception(exc_type, exc_value, exc_traceback) -> None:

    logging.info(f"An uncaught exception occurred: {exc_type}, {exc_value}, {exc_traceback}")

    if exc_traceback:
        format_exception = traceback.format_tb(exc_traceback)
        for line in format_exception:
            logging.info(f"{repr(line)}")
    
    sys.exit()

sys.excepthook = handle_exception

def getDateFolder() -> dict:

    toreturn = {}

    # Look in GFDL subfolder for date-wise folders
    gfdl_path = os.path.join(config.GDFL_FILES_FOLDER[0], "GFDL")
    
    if not os.path.exists(gfdl_path):
        logging.error(f"GFDL folder not found at {gfdl_path}")
        return toreturn
    
    tickDateWiseFolder = os.listdir(gfdl_path)
    tickDateWiseFolder = [ii for ii in tickDateWiseFolder if os.path.isdir(os.path.join(gfdl_path, ii))]

    for ii in tickDateWiseFolder:

        keyy = ii.split("_")[-1]  # Extract date from folder name (e.g., 01012025 from BFO_TICK_01012025)
        if keyy not in toreturn:
            toreturn[keyy] = set()
        
        toreturn[keyy].add(os.path.join(gfdl_path, ii))

    return toreturn

def getFinalDatasetToPush(dataFilePath: str, optionInfo: dict, tableName: str, isFutureDataFile: bool, tradingDateStr: str) -> None:

    logging.info(f"Started processing: {dataFilePath}")

    try:

        optDataset = pd.read_csv(dataFilePath)
        optDataset.columns = [ii.strip().replace("<", "").replace(">", "").lower() for ii in optDataset.columns]
        optDataset = optDataset.rename(columns={
            "o/i": "oi", "ticker": "symbol", "open interest": "oi", "higgh": "high", "dtae": "date", "openinterest": "oi", "opne interest": "oi", 
            "open inerest": "oi", "closeq": "close", "ltq": "volume"
        })

        optDataset = optDataset[(~pd.isnull(optDataset['symbol'])) & (optDataset['volume'] != 0)]
        optDataset = optDataset.drop_duplicates(subset=['time'], keep="last")
        optDataset['symbol'] = optionInfo['symbolName']

        for columnss in ['date', 'time']:
            optDataset[columnss] = optDataset[columnss].str.strip()

        # Parse time to validate market hours but keep original format
        optDataset["time_parsed"] = pd.to_datetime(optDataset["time"], format="%H:%M:%S")
        
        try:
            optDataset['date_parsed'] = pd.to_datetime(optDataset['date'], format="%d/%m/%Y")
        except Exception:
            optDataset['date_parsed'] = pd.to_datetime(optDataset['date'], format="%d-%m-%Y")
        
        if not isFutureDataFile:
            optDataset['expiry'] = optionInfo['expiry']
            optDataset['strike'] = optionInfo['strike']
        
        # Filter by market hours using parsed time
        optDataset['toKeep'] = optDataset.apply(lambda x: config.MARKET_TIMINGS[optionInfo['exchange']]['start'] <= x['time_parsed'].time() <= config.MARKET_TIMINGS[optionInfo['exchange']]['end'], axis=1)
        optDataset = optDataset[optDataset['toKeep']]
        if optDataset.empty:
            return

        # Drop temporary columns
        optDataset = optDataset.drop(columns=['toKeep', 'time_parsed', 'date_parsed'])
        
        # Keep original LTP as all OHLC values
        optDataset['open'] = optDataset['high'] = optDataset['low'] = optDataset['close'] = optDataset['ltp']

        if isFutureDataFile:
            optDataset = optDataset[['date', 'time', 'symbol', 'open', 'high', 'low', 'close', 'volume', 'oi']]
        else:
            optDataset = optDataset[['date', 'time', 'symbol', 'strike', 'expiry', 'open', 'high', 'low', 'close', 'volume', 'oi']]

        # Save to file - create separate parquet file for each date with date in filename
        filePath = os.path.join(config.UPLOAD_DIR, f"{tableName}_{tradingDateStr}.parquet")
        
        if os.path.exists(filePath):
            # Append mode: read existing file, concatenate, and save
            existing_data = pd.read_parquet(filePath)
            optDataset = pd.concat([existing_data, optDataset], ignore_index=True)
            optDataset.to_parquet(filePath, index=False, engine='pyarrow', compression='snappy')
        else:
            # Create new file
            optDataset.to_parquet(filePath, index=False, engine='pyarrow', compression='snappy')
            
        return
    
    except Exception:
        logging.error(traceback.format_exc())

    return


if __name__ == "__main__":
    
    logging.info("Utility started.")

    DATE_FOLDERS = getDateFolder()
    if len(sys.argv) != 3:
        logging.info("Command line parameters are not passed properly.")
        exit()

    uPara = {"index": sys.argv[1].upper(), "instrument_type": sys.argv[2].lower()}

    logging.info(f"Got following folder info {DATE_FOLDERS} for DB updation for {uPara}.")
    
    # Database connections disabled - working in CSV-only mode
    # Use hardcoded exchange mappings instead of fetching from database
    INSTRUMENT_INFO = {
        "NIFTY": {"exchange": "NFO"},
        "BANKNIFTY": {"exchange": "NFO"},
        "FINNIFTY": {"exchange": "NFO"},
        "MIDCPNIFTY": {"exchange": "NFO"},
        "NIFTYNXT50": {"exchange": "NFO"},
        "SENSEX": {"exchange": "BFO"},
        "BANKEX": {"exchange": "BFO"}
    }

    for tradingdatekey in DATE_FOLDERS:     

        tradingdate = int(datetime.strptime(tradingdatekey, '%d%m%Y').strftime('%y%m%d'))
        for folderpath in DATE_FOLDERS[tradingdatekey]:

            containssubfolder = ("Futures" in os.listdir(folderpath)) or ("Options" in os.listdir(folderpath))

            logging.info(f"Started processing folder: {folderpath} for {uPara}")

            if uPara['instrument_type'] == "future":

                if containssubfolder:
                    folderpath = os.path.join(os.path.join(folderpath, "Futures"), "-I")
                
                existingfilesnamesinfolder = os.listdir(folderpath)

                # Database duplicate check disabled - processing all data
                # Will always process futures data in CSV-only mode
            
                # Look for futures files - handle both NFO format (INDEX-I.) and BFO format (INDEXDDMMMYYFUT.)
                futurefilepath = []
                
                # Check for NFO format: NIFTY-I.NFO.csv
                nfo_pattern = [ii for ii in existingfilesnamesinfolder if ii.startswith(f"{uPara['index'].upper()}-I.")]
                
                # Check for BFO format: SENSEX07JAN25FUT.BFO.csv (any date)
                bfo_pattern = [ii for ii in existingfilesnamesinfolder 
                              if ii.startswith(uPara['index'].upper()) and 'FUT' in ii and ii.endswith('.csv')]
                
                futurefilepath = nfo_pattern if nfo_pattern else bfo_pattern

                if len(futurefilepath) >= 1:
                    # Process all future files found (in case of multiple dates in BFO format)
                    for future_file in futurefilepath:
                        getFinalDatasetToPush(
                            dataFilePath=os.path.join(folderpath, future_file), 
                            optionInfo={
                                "underlyingName": uPara['index'], 
                                "symbolName": uPara['index'], 
                                "exchange": INSTRUMENT_INFO[uPara['index']]['exchange']
                            }, 
                            tableName=f"{uPara['index'].lower()}_future", 
                            isFutureDataFile=True,
                            tradingDateStr=tradingdatekey
                        )
                else:
                    logging.info(f"{uPara['index']}, Unable to find future file. Hence, can't process data.")
                    
            else:

                if containssubfolder:
                    folderpath = os.path.join(folderpath, "Options")

                existingfilesnamesinfolder = os.listdir(folderpath)
            
                tableName = f"{uPara['index'].lower()}_{uPara['instrument_type']}"

                # Database check disabled - processing all option files found
                # Filter files for the specific index and option type (CE/PE)
                option_suffix = "CE" if uPara['instrument_type'] == "call" else "PE"
                
                # Get all option files matching the index and option type
                relevant_files = [f for f in existingfilesnamesinfolder 
                                 if f.startswith(uPara['index']) and option_suffix in f and f.endswith('.csv')]
                
                logging.info(f"Found {len(relevant_files)} {uPara['instrument_type']} files for {uPara['index']} in {tradingdatekey}")
                
                # Process each option file
                for filename in relevant_files:
                    symbolName = filename.split(".")[0]  # Remove extension
                    
                    # Parse strike and expiry from filename
                    # Format: NIFTY03JAN2524000CE or SENSEX28JAN2558000PE
                    try:
                        # Extract strike price and expiry date from filename
                        # Match pattern: INDEX + DDMMMYY + STRIKE + CE/PE
                        match = re.search(r'(\d{2})([A-Z]{3})(\d{2})(\d+)(CE|PE)', symbolName)
                        if match:
                            day = match.group(1)
                            month = match.group(2)
                            year = match.group(3)
                            strike = float(match.group(4))
                            
                            # Convert expiry to DD/MM/YYYY format
                            month_num = config.VALID_MONTHS.index(month) + 1
                            expiry = f"{day}/{month_num:02d}/20{year}"
                            
                            getFinalDatasetToPush(
                                dataFilePath=os.path.join(folderpath, filename), 
                                optionInfo={
                                    "underlyingName": uPara['index'], 
                                    "symbolName": symbolName, 
                                    "expiry": expiry, 
                                    "strike": strike, 
                                    "exchange": INSTRUMENT_INFO[uPara['index']]['exchange']
                                }, 
                                tableName=tableName, 
                                isFutureDataFile=False,
                                tradingDateStr=tradingdatekey
                            )
                        else:
                            logging.warning(f"Could not parse filename: {filename}")
                    except Exception as e:
                        logging.error(f"Error processing file {filename}: {str(e)}")

    logging.info("Utility stopped.")
