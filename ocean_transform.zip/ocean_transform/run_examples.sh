#!/bin/bash
# Example commands for running the transformation script

echo "=================================================="
echo "Nautilus Data Transformation - Usage Examples"
echo "=================================================="
echo ""

echo "1. Test connection first:"
echo "   python test_spaces_connection.py"
echo ""

echo "2. Transform small date range (testing):"
echo "   python transform_official_nautilus.py \\"
echo "       --bucket historical-db-1min \\"
echo "       --output-dir /root/nautilus_catalog \\"
echo "       --symbols NIFTY \\"
echo "       --start-date 2024-01-02 \\"
echo "       --end-date 2024-01-05"
echo ""

echo "3. Transform full month:"
echo "   python transform_official_nautilus.py \\"
echo "       --bucket historical-db-1min \\"
echo "       --output-dir /root/nautilus_catalog \\"
echo "       --symbols NIFTY BANKNIFTY \\"
echo "       --start-date 2024-01-01 \\"
echo "       --end-date 2024-01-31"
echo ""

echo "4. Transform multiple months (loop):"
echo "   for month in 01 02 03; do"
echo "       python transform_official_nautilus.py \\"
echo "           --symbols NIFTY BANKNIFTY \\"
echo "           --start-date 2024-\${month}-01 \\"
echo "           --end-date 2024-\${month}-31"
echo "   done"
echo ""

echo "5. Transform with custom output directory:"
echo "   python transform_official_nautilus.py \\"
echo "       --bucket historical-db-1min \\"
echo "       --output-dir /data/nautilus_2024_q1 \\"
echo "       --symbols NIFTY BANKNIFTY \\"
echo "       --start-date 2024-01-01 \\"
echo "       --end-date 2024-03-31"
echo ""

echo "=================================================="
echo "Note: Run these commands from the project directory"
echo "=================================================="

