#!/usr/bin/env python3
"""
Check Missing Dates in DigitalOcean Spaces

Identifies missing dates for each symbol and category in the bucket.
Outputs missing dates to CSV format.

Author: MarvelQuant
Date: 2025-10-30
"""

import boto3
import csv
from datetime import datetime, timedelta
from collections import defaultdict
from botocore.exceptions import ClientError

# DigitalOcean Spaces configuration
DO_ENDPOINT = "https://blr1.digitaloceanspaces.com"
DO_REGION = "blr1"
SPACE_NAME = "historical-db-tick"
SPACE_PREFIX = "raw/parquet_data"

# Credentials
ACCESS_KEY = "DO00CDX8Z7BFTQJ9W2AZ"
SECRET_KEY = "kR159s1x7Xjfd6RhVIyw8X34UGLIFKSzP7/0fG6Yt9I"

# NSE Trading Days CSV file
NSE_TRADING_DAYS_CSV = "nse_trading_days_2024_to_2025_10_30.csv"

# Symbols to check
SYMBOLS = ["banknifty", "nifty", "finnifty", "sensex", "crudeoil", "naturalgas", "goldm", "silverm"]

# File types
FILE_TYPES = {
    'futures': ['future'],
    'options': ['call', 'put'],
}


def load_nse_trading_days(csv_file):
    """Load NSE trading days from CSV file"""
    print(f"Loading NSE trading days from: {csv_file}")
    
    trading_days = []
    
    try:
        with open(csv_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                date_str = row['Date']  # Format: DD-MM-YYYY
                try:
                    date = datetime.strptime(date_str, '%d-%m-%Y')
                    trading_days.append(date)
                except ValueError:
                    # Skip invalid rows
                    continue
        
        print(f"[OK] Loaded {len(trading_days)} NSE trading days")
        print(f"     Date range: {trading_days[0].strftime('%Y-%m-%d')} to {trading_days[-1].strftime('%Y-%m-%d')}")
        return trading_days
        
    except FileNotFoundError:
        print(f"[ERROR] NSE trading days file not found: {csv_file}")
        print("        Please ensure the file exists in the same directory.")
        return []
    except Exception as e:
        print(f"[ERROR] Error reading NSE trading days: {e}")
        return []


def parse_filename(filename):
    """Parse filename to extract symbol, type, and date"""
    # Expected format: symbol_type_DDMMYYYY.parquet
    parts = filename.replace('.parquet', '').split('_')
    
    if len(parts) < 3:
        return None
    
    symbol = parts[0]
    file_type = parts[1]
    date_str = parts[2]
    
    # Parse date DDMMYYYY
    try:
        date = datetime.strptime(date_str, '%d%m%Y')
        return {
            'symbol': symbol,
            'type': file_type,
            'date': date
        }
    except ValueError:
        return None


def list_all_files():
    """List all files in the bucket and parse them"""
    print("Connecting to DigitalOcean Spaces...")
    
    s3_client = boto3.client(
        's3',
        region_name=DO_REGION,
        endpoint_url=DO_ENDPOINT,
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY
    )
    
    print(f"Listing files in bucket '{SPACE_NAME}'...")
    
    all_files = []
    continuation_token = None
    page_count = 0
    
    try:
        while True:
            page_count += 1
            
            params = {
                'Bucket': SPACE_NAME,
                'Prefix': SPACE_PREFIX
            }
            
            if continuation_token:
                params['ContinuationToken'] = continuation_token
            
            response = s3_client.list_objects_v2(**params)
            
            if 'Contents' in response:
                page_objects = response['Contents']
                
                for obj in page_objects:
                    full_path = obj['Key']
                    filename = full_path.split('/')[-1]
                    
                    parsed = parse_filename(filename)
                    if parsed:
                        all_files.append(parsed)
                
                print(f"  Page {page_count}: Processed {len(page_objects)} objects (Total parsed: {len(all_files)})")
            
            if response.get('IsTruncated', False):
                continuation_token = response.get('NextContinuationToken')
            else:
                break
        
        print(f"\n[OK] Total files parsed: {len(all_files)}")
        return all_files
        
    except ClientError as e:
        print(f"[ERROR] Error listing objects: {e}")
        return []


def organize_files_by_symbol_type(files):
    """Organize files by symbol and type"""
    organized = defaultdict(lambda: defaultdict(set))
    
    for file_info in files:
        symbol = file_info['symbol']
        file_type = file_info['type']
        date = file_info['date']
        
        organized[symbol][file_type].add(date)
    
    return organized


def find_missing_dates(organized_files, expected_dates):
    """Find missing dates for each symbol and type"""
    missing_data = []
    
    print("\n" + "=" * 80)
    print("CHECKING FOR MISSING DATES")
    print("=" * 80)
    
    expected_date_set = set(expected_dates)
    
    for symbol in SYMBOLS:
        print(f"\nChecking symbol: {symbol.upper()}")
        
        # Check futures
        print(f"  Checking futures...")
        if 'future' in organized_files[symbol]:
            existing_dates = organized_files[symbol]['future']
            missing = expected_date_set - existing_dates
            
            for missing_date in sorted(missing):
                missing_data.append({
                    'symbol': symbol,
                    'type': 'future',
                    'category': 'futures',
                    'missing_date': missing_date.strftime('%Y-%m-%d'),
                    'missing_date_ddmmyyyy': missing_date.strftime('%d%m%Y'),
                    'expected_filename': f"{symbol}_future_{missing_date.strftime('%d%m%Y')}.parquet"
                })
            
            print(f"    Found: {len(existing_dates)} files, Missing: {len(missing)} dates")
        else:
            print(f"    No files found! All {len(expected_date_set)} dates are missing")
            for missing_date in sorted(expected_date_set):
                missing_data.append({
                    'symbol': symbol,
                    'type': 'future',
                    'category': 'futures',
                    'missing_date': missing_date.strftime('%Y-%m-%d'),
                    'missing_date_ddmmyyyy': missing_date.strftime('%d%m%Y'),
                    'expected_filename': f"{symbol}_future_{missing_date.strftime('%d%m%Y')}.parquet"
                })
        
        # Check options (call and put)
        for option_type in ['call', 'put']:
            print(f"  Checking {option_type}s...")
            if option_type in organized_files[symbol]:
                existing_dates = organized_files[symbol][option_type]
                missing = expected_date_set - existing_dates
                
                for missing_date in sorted(missing):
                    missing_data.append({
                        'symbol': symbol,
                        'type': option_type,
                        'category': 'options',
                        'missing_date': missing_date.strftime('%Y-%m-%d'),
                        'missing_date_ddmmyyyy': missing_date.strftime('%d%m%Y'),
                        'expected_filename': f"{symbol}_{option_type}_{missing_date.strftime('%d%m%Y')}.parquet"
                    })
                
                print(f"    Found: {len(existing_dates)} files, Missing: {len(missing)} dates")
            else:
                print(f"    No files found! All {len(expected_date_set)} dates are missing")
                for missing_date in sorted(expected_date_set):
                    missing_data.append({
                        'symbol': symbol,
                        'type': option_type,
                        'category': 'options',
                        'missing_date': missing_date.strftime('%Y-%m-%d'),
                        'missing_date_ddmmyyyy': missing_date.strftime('%d%m%Y'),
                        'expected_filename': f"{symbol}_{option_type}_{missing_date.strftime('%d%m%Y')}.parquet"
                    })
    
    return missing_data


def export_missing_to_csv(missing_data, filename="missing_dates.csv"):
    """Export missing dates to CSV"""
    print("\n" + "=" * 80)
    print(f"EXPORTING MISSING DATES TO CSV: {filename}")
    print("=" * 80)
    
    if not missing_data:
        print("\n[OK] No missing dates found! All data is complete.")
        # Still create an empty CSV with headers
        with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=[
                'symbol', 'type', 'category', 'missing_date', 'missing_date_ddmmyyyy', 'expected_filename'
            ])
            writer.writeheader()
        return
    
    with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = ['symbol', 'type', 'category', 'missing_date', 'missing_date_ddmmyyyy', 'expected_filename']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        for entry in missing_data:
            writer.writerow(entry)
    
    print(f"\n[OK] Exported {len(missing_data)} missing date entries to {filename}")
    
    # Print summary
    print("\n" + "=" * 80)
    print("MISSING DATES SUMMARY")
    print("=" * 80)
    
    # Group by symbol and type
    summary = defaultdict(lambda: defaultdict(int))
    for entry in missing_data:
        summary[entry['symbol']][entry['type']] += 1
    
    total_missing = 0
    for symbol in sorted(summary.keys()):
        print(f"\n{symbol.upper()}:")
        for file_type in sorted(summary[symbol].keys()):
            count = summary[symbol][file_type]
            total_missing += count
            print(f"  {file_type:10s}: {count:5d} missing dates")
    
    print(f"\n{'TOTAL':15s}: {total_missing:5d} missing date entries")
    print("=" * 80)


def export_summary_csv(missing_data, filename="missing_dates_summary.csv"):
    """Export a summary CSV with counts"""
    summary = defaultdict(lambda: defaultdict(int))
    for entry in missing_data:
        summary[entry['symbol']][entry['type']] += 1
    
    with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['Symbol', 'Type', 'Category', 'Missing Count'])
        
        for symbol in sorted(summary.keys()):
            for file_type in sorted(summary[symbol].keys()):
                count = summary[symbol][file_type]
                category = 'futures' if file_type == 'future' else 'options'
                writer.writerow([symbol, file_type, category, count])
    
    print(f"[OK] Summary exported to {filename}")


def main():
    print("=" * 80)
    print("DIGITALOCEAN SPACES - MISSING DATES CHECKER")
    print("=" * 80)
    print(f"Symbols: {', '.join(SYMBOLS)}")
    print(f"Bucket: {SPACE_NAME}")
    print(f"Prefix: {SPACE_PREFIX}")
    print("\n" + "=" * 80)
    
    # Load NSE trading days from CSV
    print("\nLoading NSE trading days...")
    expected_dates = load_nse_trading_days(NSE_TRADING_DAYS_CSV)
    
    if not expected_dates:
        print("[ERROR] Cannot proceed without NSE trading days data")
        return
    
    print(f"\n[OK] Will check against {len(expected_dates)} official NSE trading days")
    
    # List all files
    all_files = list_all_files()
    
    if not all_files:
        print("[ERROR] No files found or error occurred")
        return
    
    # Organize files by symbol and type
    print("\nOrganizing files by symbol and type...")
    organized_files = organize_files_by_symbol_type(all_files)
    
    # Find missing dates
    missing_data = find_missing_dates(organized_files, expected_dates)
    
    # Export to CSV
    export_missing_to_csv(missing_data, "missing_dates.csv")
    export_summary_csv(missing_data, "missing_dates_summary.csv")
    
    print("\n" + "=" * 80)
    print("[COMPLETE] Missing dates check complete!")
    print(f"  Detailed list: missing_dates.csv")
    print(f"  Summary: missing_dates_summary.csv")
    print("=" * 80)


if __name__ == "__main__":
    main()

