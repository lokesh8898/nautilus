#!/usr/bin/env python3
"""
Official Nautilus Data Transformation Pattern - DigitalOcean Spaces Edition

Follows the verified pattern from nautilus_trader/examples/backtest/
- example_01_load_bars_from_custom_csv/run_example.py
- example_04_using_data_catalog/run_example.py

Transforms NSE data (index, futures, options) from DigitalOcean Spaces to Nautilus catalog format.

Data Source: DigitalOcean Spaces (S3-compatible object storage)
Output: Local Nautilus Parquet Catalog

Usage:
    python transform_official_nautilus.py --bucket historical-db-1min --output-dir /root/nautilus_catalog
"""

import sys
import os
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path, PurePosixPath
from datetime import datetime, timedelta
import argparse
import logging

import boto3
from botocore.config import Config

# Add repository root to path so package imports resolve when run as a script
# Use parent directory (current directory is the project root)
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

import pandas as pd
from nautilus_trader.model.identifiers import InstrumentId, Symbol, Venue
from nautilus_trader.model.data import BarType, QuoteTick
from nautilus_trader.model.instruments import Equity, OptionContract, FuturesContract
from nautilus_trader.model.objects import Price, Quantity, Currency
from nautilus_trader.persistence.catalog.parquet import ParquetDataCatalog
from nautilus_trader.persistence.wranglers import BarDataWrangler, QuoteTickDataWrangler

# Import our contract generators
from marvelquant_data.utils.contract_generators import (
    create_options_contract,
    create_futures_contract,
    parse_nse_option_symbol
)

# Import custom data types
from marvelquant_data.data_types import OptionOI, FutureOI

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
logger = logging.getLogger(__name__)

# IST offset (5 hours 30 minutes)
IST_OFFSET = timedelta(hours=5, minutes=30)

INDEX_DIR_CANDIDATES = ("index", "cash")
OPTION_DIR_CANDIDATES = ("option", "options")


@dataclass(frozen=True)
class SpacesConfig:
    bucket: str
    region: str
    endpoint_url: str
    access_key: str
    secret_key: str
    profile: str | None = None


class SpacesClient:
    """
    Thin wrapper around boto3 S3 client configured for DigitalOcean Spaces.
    """

    def __init__(self, config: SpacesConfig) -> None:
        session_kwargs: dict[str, str] = {}
        if config.profile:
            session_kwargs["profile_name"] = config.profile

        session = boto3.session.Session(**session_kwargs)
        boto_config = Config(
            signature_version="s3v4",
            s3={"addressing_style": "virtual"},
            retries={"max_attempts": 5, "mode": "adaptive"},
        )

        self._client = session.client(
            "s3",
            region_name=config.region,
            endpoint_url=config.endpoint_url,
            aws_access_key_id=config.access_key,
            aws_secret_access_key=config.secret_key,
            config=boto_config,
        )
        self.bucket = config.bucket

    @staticmethod
    def _ensure_slash(prefix: str) -> str:
        if prefix and not prefix.endswith("/"):
            return prefix + "/"
        return prefix

    def list_directories(self, prefix: str = "") -> list[str]:
        """
        List "folders" directly under the provided prefix.
        """
        normalized_prefix = self._ensure_slash(prefix)
        paginator = self._client.get_paginator("list_objects_v2")
        directories: list[str] = []

        for page in paginator.paginate(
            Bucket=self.bucket,
            Prefix=normalized_prefix,
            Delimiter="/",
        ):
            directories.extend(
                common["Prefix"] for common in page.get("CommonPrefixes", [])
            )

        return directories

    def prefix_exists(self, prefix: str) -> bool:
        """
        Check whether any object exists under the given prefix.
        """
        normalized_prefix = self._ensure_slash(prefix)
        response = self._client.list_objects_v2(
            Bucket=self.bucket,
            Prefix=normalized_prefix,
            MaxKeys=1,
        )
        return response.get("KeyCount", 0) > 0

    def list_objects(self, prefix: str, suffix: str | None = None) -> list[str]:
        """
        List object keys under a prefix, optionally filtering by suffix.
        """
        paginator = self._client.get_paginator("list_objects_v2")
        keys: list[str] = []

        for page in paginator.paginate(Bucket=self.bucket, Prefix=prefix):
            for item in page.get("Contents", []):
                key = item["Key"]
                if suffix and not key.endswith(suffix):
                    continue
                keys.append(key)

        return keys

    def read_parquet(self, key: str) -> pd.DataFrame:
        """
        Fetch a parquet object into a pandas DataFrame.
        """
        response = self._client.get_object(Bucket=self.bucket, Key=key)
        with BytesIO(response["Body"].read()) as buffer:
            return pd.read_parquet(buffer)


class SpacesDataSource:
    """
    Helper to work with parquet data stored in DigitalOcean Spaces.
    """

    def __init__(self, client: SpacesClient, base_prefix: str = "") -> None:
        self._client = client
        base_prefix = base_prefix.strip("/")
        self._base_parts = [part for part in base_prefix.split("/") if part]

    def _build_prefix(self, parts: tuple[str, ...]) -> str:
        prefix_parts = self._base_parts + [part.strip("/") for part in parts if part]
        if not prefix_parts:
            return ""
        return "/".join(prefix_parts) + "/"

    def resolve_prefix(self, *parts: str) -> str:
        return self._build_prefix(parts)

    def format_prefix(self, *parts: str) -> str:
        prefix = self.resolve_prefix(*parts)
        if not prefix:
            return "<root>"
        return prefix.rstrip("/")

    def prefix_exists(self, *parts: str) -> bool:
        prefix = self.resolve_prefix(*parts)
        return self._client.prefix_exists(prefix)

    def list_directories(self, *parts: str) -> list[str]:
        prefix = self.resolve_prefix(*parts)
        directories = self._client.list_directories(prefix)
        base_len = len(prefix)
        return [directory[base_len:].rstrip("/") for directory in directories]

    def list_parquet_files(self, *parts: str) -> list[str]:
        prefix = self.resolve_prefix(*parts)
        return self._client.list_objects(prefix, suffix=".parquet")

    def read_parquet(self, key: str) -> pd.DataFrame:
        return self._client.read_parquet(key)

    @property
    def bucket(self) -> str:
        return self._client.bucket


def find_index_directory(data_source: SpacesDataSource, symbol: str) -> tuple[str, str] | None:
    symbol_lower = symbol.lower()
    for directory_name in INDEX_DIR_CANDIDATES:
        if data_source.prefix_exists(directory_name, symbol_lower):
            return directory_name, symbol_lower
    return None


def find_option_directories(data_source: SpacesDataSource, symbol: str) -> list[str]:
    """
    Find option directories in Spaces for the given symbol.
    Returns list of prefix paths (e.g., ["option/nifty", "option/nifty_call"]).
    """
    symbol_lower = symbol.lower()
    option_prefixes: list[str] = []
    seen: set[str] = set()

    for directory_name in OPTION_DIR_CANDIDATES:
        # Check direct symbol directory
        direct = f"{directory_name}/{symbol_lower}"
        if data_source.prefix_exists(directory_name, symbol_lower) and direct not in seen:
            option_prefixes.append(direct)
            seen.add(direct)

        # Check with _call and _put suffixes
        for suffix in ("_call", "_put"):
            candidate = f"{directory_name}/{symbol_lower}{suffix}"
            if data_source.prefix_exists(directory_name, f"{symbol_lower}{suffix}") and candidate not in seen:
                option_prefixes.append(candidate)
                seen.add(candidate)

    return option_prefixes


def normalize_price_columns(df: pd.DataFrame, columns: list[str]) -> bool:
    """
    Ensure price columns are floating point and scale paise-based data to rupees.

    Returns:
        True if scaling (÷100) was applied, otherwise False.
    """
    if df.empty:
        return False

    df[columns] = df[columns].astype(float)
    max_abs_value = df[columns].abs().max().max()

    if max_abs_value > 100_000:
        df[columns] = df[columns] / 100.0
        return True

    return False


def bars_to_quote_ticks(bars, instrument):
    """
    Convert Bar data to QuoteTicks for Greeks calculation.

    Creates QuoteTicks where bid=ask=close price.
    This is required for NautilusTrader Greeks calculator.
    """
    quote_ticks = []

    for bar in bars:
        # Create QuoteTick using close price as both bid and ask
        price = Price(bar.close.as_double(), instrument.price_precision)
        size = Quantity(1, instrument.size_precision)

        tick = QuoteTick(
            instrument_id=instrument.id,
            bid_price=price,
            ask_price=price,
            bid_size=size,
            ask_size=size,
            ts_event=bar.ts_event,
            ts_init=bar.ts_init,
        )
        quote_ticks.append(tick)

    return quote_ticks


def yyyymmdd_seconds_to_datetime(date_int: int, time_int: int) -> datetime:
    """
    Convert YYYYMMDD integer + seconds to datetime in UTC.
    
    Args:
        date_int: Date as YYYYMMDD (e.g., 20240102) or YYMMDD (e.g., 240102 / 251001)
        time_int: Time as seconds since midnight (e.g., 33300 = 09:15:00)
    
    Returns:
        datetime in UTC
    """
    # Parse date
    if date_int >= 10_000_000:
        year = date_int // 10000
        month = (date_int % 10000) // 100
        day = date_int % 100
    elif date_int >= 100_000:
        # Handle YYMMDD sources (assume 2000s)
        year = 2000 + (date_int // 10000)
        month = (date_int % 10000) // 100
        day = date_int % 100
    else:
        raise ValueError(f"Unsupported date format: {date_int}")
    
    # Parse time
    hours = time_int // 3600
    minutes = (time_int % 3600) // 60
    seconds = time_int % 60
    
    # Create IST datetime (naive)
    ist_dt = datetime(year, month, day, hours, minutes, seconds)
    
    # Convert to UTC
    utc_dt = ist_dt - IST_OFFSET
    
    return utc_dt


def transform_index_bars(
    data_source: SpacesDataSource,
    catalog: ParquetDataCatalog,
    symbol: str,
    start_date: str,
    end_date: str
) -> int:
    """
    Transform index data to Nautilus Bar format (OFFICIAL PATTERN).
    
    Args:
        data_source: SpacesDataSource for reading from DigitalOcean Spaces
        catalog: Nautilus ParquetDataCatalog instance
        symbol: Symbol name (e.g., "NIFTY", "BANKNIFTY")
        start_date: Start date (YYYY-MM-DD)
        end_date: End date (YYYY-MM-DD)
    
    Returns:
        Number of bars created
    """
    logger.info(f"Transforming {symbol} index bars...")
    
    # Resolve index directory (supports legacy 'index' and new 'cash' folders)
    result = find_index_directory(data_source, symbol)
    if not result:
        logger.warning(
            f"No index/cash directory found for {symbol} "
            f"(checked: {', '.join(INDEX_DIR_CANDIDATES)})"
        )
        return 0

    directory_name, symbol_lower = result
    logger.info(f"Using index source directory: {directory_name}/{symbol_lower}")

    # Find all parquet files for this symbol
    parquet_files = data_source.list_parquet_files(directory_name, symbol_lower)
    
    if not parquet_files:
        logger.warning(f"No parquet files found in {directory_name}/{symbol_lower}")
        return 0
    
    # Read all files into one DataFrame
    dfs = []
    for file_key in parquet_files:
        try:
            df = data_source.read_parquet(file_key)
            dfs.append(df)
        except Exception as e:
            logger.warning(f"Error reading {file_key}: {e}")
            continue
    
    if not dfs:
        logger.error("No data loaded")
        return 0
    
    # Combine all dataframes
    combined_df = pd.concat(dfs, ignore_index=True)
    
    # Convert date + time to datetime timestamp
    combined_df['timestamp'] = combined_df.apply(
        lambda row: yyyymmdd_seconds_to_datetime(row['date'], row['time']),
        axis=1
    )
    
    logger.info(f"Data range: {combined_df['timestamp'].min()} to {combined_df['timestamp'].max()}")
    
    # Filter by date range (account for IST->UTC conversion: IST dates start at UTC-5:30)
    start = pd.to_datetime(start_date) - pd.Timedelta(hours=6)  # Buffer for IST conversion
    end = pd.to_datetime(end_date) + pd.Timedelta(days=1)
    combined_df = combined_df[(combined_df['timestamp'] >= start) & 
                               (combined_df['timestamp'] < end)]
    
    if combined_df.empty:
        logger.warning(f"No data in date range {start_date} to {end_date}")
        return 0

    if "volume" not in combined_df.columns:
        logger.info("No volume column present for %s index data; defaulting to zeros.", symbol)
        combined_df["volume"] = 0.0
    
    # OFFICIAL PATTERN: Prepare DataFrame for BarDataWrangler
    # Required: columns ['open', 'high', 'low', 'close', 'volume'] with 'timestamp' as INDEX
    bar_df = combined_df[['timestamp', 'open', 'high', 'low', 'close', 'volume']].copy()

    if normalize_price_columns(bar_df, ["open", "high", "low", "close"]):
        logger.info("Scaled %s index prices from paise to rupees.", symbol)

    # Prices are now normalized to rupees with 0.05 tick size

    bar_df = bar_df.set_index('timestamp')  # CRITICAL: Set timestamp as index!
    bar_df = bar_df.sort_index()  # Sort by timestamp
    
    # Create instrument
    instrument_id = InstrumentId(
        symbol=Symbol(f"{symbol}-INDEX"),
        venue=Venue("NSE")
    )
    
    instrument = Equity(
        instrument_id=instrument_id,
        raw_symbol=Symbol(symbol),
        currency=Currency.from_str("INR"),
        price_precision=2,
        price_increment=Price(0.05, 2),
        lot_size=Quantity.from_int(1),
        ts_event=0,
        ts_init=0,
    )
    
    # Create bar type
    bar_type = BarType.from_str(f"{instrument_id}-1-MINUTE-LAST-EXTERNAL")
    
    # OFFICIAL PATTERN: Use BarDataWrangler
    wrangler = BarDataWrangler(bar_type, instrument)
    bars = wrangler.process(
        data=bar_df,
        default_volume=0.0,  # Index data has no real volume
        ts_init_delta=0
    )
    
    # OFFICIAL PATTERN: Write to catalog
    catalog.write_data([instrument])  # Write instrument first
    catalog.write_data(bars, skip_disjoint_check=True)  # Skip check for overlapping data

    # Generate and write QuoteTicks for Greeks calculation
    quote_ticks = bars_to_quote_ticks(bars, instrument)
    catalog.write_data(quote_ticks, skip_disjoint_check=True)
    logger.info(f"✅ {symbol}: Created {len(bars):,} bars + {len(quote_ticks):,} QuoteTicks")

    return len(bars)


def transform_futures_bars(
    data_source: SpacesDataSource,
    catalog: ParquetDataCatalog,
    symbol: str,
    start_date: str,
    end_date: str,
    output_dir: Path = None
) -> tuple[int, None]:
    """
    Transform futures data to Nautilus Bar format + separate OI DataFrame.
    
    Returns:
        (bar_count, oi_dataframe)
    """
    logger.info(f"Transforming {symbol} futures bars...")
    
    symbol_lower = symbol.lower()
    
    # Check if futures directory exists
    if not data_source.prefix_exists("futures", symbol_lower):
        logger.warning(f"No futures directory found for {symbol}")
        return 0, None

    # List all parquet files in futures directory
    parquet_files = data_source.list_parquet_files("futures", symbol_lower)

    if not parquet_files:
        logger.warning(f"No parquet files found in futures/{symbol_lower}")
        return 0, None

    # CRITICAL: Only use dated files (nifty_future_YYYYMMDD.parquet) which are in RUPEES
    # Exclude data.parquet (in paise) and futures_data.parquet (corrupt)
    dated_files = [f for f in parquet_files if f"{symbol_lower}_future_" in f]

    if not dated_files:
        logger.warning(f"No dated futures files found in futures/{symbol_lower}")
        return 0, None

    logger.info(f"Using {len(dated_files)} dated futures files (already in rupees)")

    dfs = []
    for file_key in dated_files:
        try:
            df = data_source.read_parquet(file_key)
            # Handle mixed date formats
            if df['date'].dtype == 'object':
                df['date'] = pd.to_datetime(df['date']).dt.strftime('%Y%m%d').astype(int)
            # Ensure time is int
            if df['time'].dtype == 'object':
                df['time'] = df['time'].astype(int)
            dfs.append(df)
        except Exception as e:
            logger.warning(f"Error reading {file_key}: {e}")
            continue
    
    if not dfs:
        return 0, None
    
    combined_df = pd.concat(dfs, ignore_index=True)
    
    # Convert to timestamp
    combined_df['timestamp'] = combined_df.apply(
        lambda row: yyyymmdd_seconds_to_datetime(row['date'], row['time']),
        axis=1
    )
    
    logger.info(f"Futures data range: {combined_df['timestamp'].min()} to {combined_df['timestamp'].max()}")
    
    # Filter by date range (account for IST->UTC conversion)
    start = pd.to_datetime(start_date) - pd.Timedelta(hours=6)
    end = pd.to_datetime(end_date) + pd.Timedelta(days=1)
    combined_df = combined_df[(combined_df['timestamp'] >= start) & 
                               (combined_df['timestamp'] < end)]
    
    if combined_df.empty:
        return 0, pd.DataFrame()
    
    # Prepare for BarDataWrangler (OHLCV only, NO OI!)
    bar_df = combined_df[['timestamp', 'open', 'high', 'low', 'close', 'volume']].copy()

    if normalize_price_columns(bar_df, ["open", "high", "low", "close"]):
        logger.info("Scaled %s futures prices from paise to rupees.", symbol)

    # Data quality fixes
    bar_df['volume'] = bar_df['volume'].clip(lower=0)  # Handle negative volumes
    
    # Fix invalid OHLC relationships (Nautilus validates: high >= close, low <= close)
    bar_df['high'] = bar_df[['high', 'close']].max(axis=1)
    bar_df['low'] = bar_df[['low', 'close']].min(axis=1)
    
    bar_df = bar_df.set_index('timestamp')
    bar_df = bar_df.sort_index()
    
    # Create FuturesContract (use proper Nautilus instrument type)
    instrument = create_futures_contract(
        symbol=f"{symbol}-I",  # -I for continuous futures
        expiry_date="continuous",  # Continuous contract
        underlying=symbol,
        venue="NSE"
    )
    
    bar_type = BarType.from_str(f"{instrument.id}-1-MINUTE-LAST-EXTERNAL")
    
    # Create bars
    wrangler = BarDataWrangler(bar_type, instrument)
    bars = wrangler.process(bar_df)
    
    # Write to catalog
    catalog.write_data([instrument])
    catalog.write_data(bars, skip_disjoint_check=True)

    # Generate and write QuoteTicks for Greeks calculation
    quote_ticks = bars_to_quote_ticks(bars, instrument)
    catalog.write_data(quote_ticks, skip_disjoint_check=True)

    # Create FutureOI custom data (Arrow serialization registered)
    oi_data_list = []
    prev_oi = 0
    for idx, row in combined_df.iterrows():
        current_oi = int(row["oi"])
        coi = current_oi - prev_oi
        prev_oi = current_oi
        ts_ns = int(row["timestamp"].timestamp() * 1_000_000_000)
        
        oi_data = FutureOI(
            instrument_id=instrument.id,
            oi=current_oi,
            coi=coi,
            ts_event=ts_ns,
            ts_init=ts_ns
        )
        oi_data_list.append(oi_data)
    
    # Write FutureOI to catalog (Arrow registered)
    if oi_data_list:
        oi_data_list.sort(key=lambda x: x.ts_init)
        catalog.write_data(oi_data_list)
        logger.info(f"✅ Saved {len(oi_data_list):,} FutureOI records")
    
    logger.info(f"✅ {symbol} futures: Created {len(bars):,} bars + {len(quote_ticks):,} QuoteTicks")
    return len(bars), None  # No longer returning DataFrame


def transform_options_bars(
    data_source: SpacesDataSource,
    catalog: ParquetDataCatalog,
    symbol: str,
    start_date: str,
    end_date: str
) -> int:
    """
    Transform options data to Nautilus Bar format (OFFICIAL PATTERN).
    Note: Processes limited files to avoid memory issues.
    """
    logger.info(f"Transforming {symbol} options bars...")
    
    option_prefixes = find_option_directories(data_source, symbol)
    if not option_prefixes:
        logger.warning(
            f"No options directories found for {symbol} "
            f"(checked: {', '.join(OPTION_DIR_CANDIDATES)})"
        )
        return 0

    logger.info(
        "Using option source directories: %s",
        ", ".join(option_prefixes),
    )
    
    # CRITICAL: Only use dated files (nifty_call/put_YYYYMMDD.parquet) which are in RUPEES
    # Similar to futures Bug #5 fix - dated files don't need paise conversion
    all_files: list[str] = []
    for option_prefix in option_prefixes:
        # Split prefix to get parts for list_parquet_files
        parts = option_prefix.split('/')
        if len(parts) == 2:
            all_files.extend(data_source.list_parquet_files(parts[0], parts[1]))
        else:
            all_files.extend(data_source.list_parquet_files(option_prefix))
    
    # Deduplicate while preserving order
    all_files = list(dict.fromkeys(all_files))

    # Filter for dated call/put files (already in rupees)
    symbol_lower = symbol.lower()
    dated_call_files = [f for f in all_files if f"{symbol_lower}_call_" in f]
    dated_put_files = [f for f in all_files if f"{symbol_lower}_put_" in f]
    parquet_files = dated_call_files + dated_put_files

    if not parquet_files:
        logger.warning(f"No dated option files found for {symbol}")
        return 0

    logger.info(f"Using {len(parquet_files)} dated option files (already in rupees)")

    total_bars = 0
    total_quote_ticks = 0
    scaled_option_prices_logged = False

    # Process dated option files (already in rupees, no conversion needed)
    for file_key in parquet_files:
        try:
            df = data_source.read_parquet(file_key)
            
            if 'symbol' not in df.columns or df.empty:
                continue
            
            # Convert timestamp
            df['timestamp'] = df.apply(
                lambda row: yyyymmdd_seconds_to_datetime(row['date'], row['time']),
                axis=1
            )
            
            # Filter by date (account for IST->UTC conversion)
            start = pd.to_datetime(start_date) - pd.Timedelta(hours=6)
            end = pd.to_datetime(end_date) + pd.Timedelta(days=1)
            df = df[(df['timestamp'] >= start) & (df['timestamp'] < end)]
            
            if df.empty:
                continue
            
            # Group by option symbol
            for option_symbol, group in df.groupby('symbol'):
                try:
                    bar_df = group[['timestamp', 'open', 'high', 'low', 'close', 'volume']].copy()

                    # Data quality fixes
                    bar_df['volume'] = bar_df['volume'].clip(lower=0)
                    bar_df['high'] = bar_df[['high', 'close', 'open']].max(axis=1)
                    bar_df['low'] = bar_df[['low', 'close', 'open']].min(axis=1)

                    if normalize_price_columns(bar_df, ["open", "high", "low", "close"]):
                        if not scaled_option_prices_logged:
                            logger.info("Scaled %s options prices from paise to rupees.", symbol)
                            scaled_option_prices_logged = True
                    
                    bar_df = bar_df.set_index('timestamp')
                    bar_df = bar_df.sort_index()
                    
                    # Create OptionContract (proper Nautilus instrument type)
                    try:
                        # Parse option symbol
                        parsed = parse_nse_option_symbol(option_symbol)
                        instrument = create_options_contract(
                            symbol=option_symbol,
                            underlying=parsed['underlying'],
                            strike=parsed['strike'],
                            expiry=parsed['expiry'],
                            option_kind=parsed['option_type'],
                            venue="NSE"
                        )
                    except Exception as parse_error:
                        logger.warning(f"Parse failed for {option_symbol}: {parse_error}, using Equity")
                        instrument_id = InstrumentId(symbol=Symbol(option_symbol), venue=Venue("NSE"))
                        instrument = Equity(
                            instrument_id=instrument_id,
                            raw_symbol=Symbol(option_symbol),
                            currency=Currency.from_str("INR"),
                            price_precision=2,
                            price_increment=Price(0.05, 2),
                            lot_size=Quantity.from_int(25 if "NIFTY" in option_symbol else 15),
                            ts_event=0,
                            ts_init=0,
                        )
                    
                    bar_type = BarType.from_str(f"{instrument.id}-1-MINUTE-LAST-EXTERNAL")
                    wrangler = BarDataWrangler(bar_type, instrument)
                    bars = wrangler.process(bar_df)
                    
                    # Write to catalog
                    catalog.write_data([instrument])
                    catalog.write_data(bars, skip_disjoint_check=True)

                    # Generate and write QuoteTicks for Greeks calculation
                    quote_ticks = bars_to_quote_ticks(bars, instrument)
                    catalog.write_data(quote_ticks, skip_disjoint_check=True)

                    # Create OptionOI custom data (Arrow serialization registered)
                    if "oi" in group.columns:
                        oi_data_list = []
                        prev_oi = 0
                        for idx, oi_row in group.iterrows():
                            current_oi = int(oi_row["oi"])
                            coi = current_oi - prev_oi
                            prev_oi = current_oi
                            ts_ns = int(oi_row["timestamp"].timestamp() * 1_000_000_000)

                            oi_data = OptionOI(
                                instrument_id=instrument.id,
                                oi=current_oi,
                                coi=coi,
                                ts_event=ts_ns,
                                ts_init=ts_ns
                            )
                            oi_data_list.append(oi_data)

                        # Write OptionOI to catalog
                        if oi_data_list:
                            oi_data_list.sort(key=lambda x: x.ts_init)
                            catalog.write_data(oi_data_list)


                    total_bars += len(bars)
                    total_quote_ticks += len(quote_ticks)
                    
                except Exception as e:
                    logger.warning(f"Error processing option {option_symbol}: {e}")
                    continue
                    
        except Exception as e:
            logger.warning(f"Error reading {file_key}: {e}")
            continue

    logger.info(f"✅ {symbol} options: Created {total_bars:,} bars + {total_quote_ticks:,} QuoteTicks")
    return total_bars


def main():
    parser = argparse.ArgumentParser(
        description="Transform NSE data from DigitalOcean Spaces to Nautilus catalog (Official Pattern)"
    )
    parser.add_argument(
        "--bucket",
        type=str,
        default="historical-db-1min",
        help="DigitalOcean Spaces bucket name"
    )
    parser.add_argument(
        "--base-prefix",
        type=str,
        default="raw/parquet_data",
        help="Base prefix within bucket (e.g., 'raw/parquet_data')"
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("/root/nautilus_catalog"),
        help="Output directory for Nautilus catalog (on SSH server)"
    )
    parser.add_argument(
        "--symbols",
        nargs="+",
        default=["NIFTY", "BANKNIFTY"],
        help="Symbols to transform"
    )
    parser.add_argument(
        "--start-date",
        type=str,
        default="2024-01-02",
        help="Start date (YYYY-MM-DD)"
    )
    parser.add_argument(
        "--end-date",
        type=str,
        default="2024-01-05",
        help="End date (YYYY-MM-DD)"
    )
    
    args = parser.parse_args()
    
    logger.info("="*80)
    logger.info("NAUTILUS DATA TRANSFORMATION - DIGITALOCEAN SPACES")
    logger.info("Following: nautilus_trader/examples/backtest/ patterns")
    logger.info("="*80)
    logger.info(f"Input: DigitalOcean Spaces bucket '{args.bucket}'")
    logger.info(f"Base prefix: '{args.base_prefix}' (empty = root)")
    logger.info(f"Output: {args.output_dir}")
    logger.info(f"Symbols: {args.symbols}")
    logger.info(f"Date range: {args.start_date} to {args.end_date}")
    logger.info("="*80)
    
    # Initialize DigitalOcean Spaces client
    logger.info("Connecting to DigitalOcean Spaces...")
    spaces_config = SpacesConfig(
        bucket=args.bucket,
        region="blr1",
        endpoint_url="https://blr1.digitaloceanspaces.com",
        access_key="DO00CDX8Z7BFTQJ9W2AZ",
        secret_key="kR159s1x7Xjfd6RhVIyw8X34UGLIFKSzP7/0fG6Yt9I"
    )
    
    spaces_client = SpacesClient(spaces_config)
    data_source = SpacesDataSource(spaces_client, base_prefix=args.base_prefix)
    
    # Test connection and list available directories
    logger.info("Testing connection...")
    try:
        directories = data_source.list_directories()
        logger.info(f"✅ Connected! Found {len(directories)} top-level directories:")
        for directory in directories[:10]:  # Show first 10
            logger.info(f"  - {directory}")
        if len(directories) > 10:
            logger.info(f"  ... and {len(directories) - 10} more")
    except Exception as e:
        logger.error(f"❌ Failed to connect to Spaces: {e}", exc_info=True)
        return
    
    logger.info("="*80)
    
    # Create catalog
    catalog = ParquetDataCatalog(path=str(args.output_dir))
    
    total_bars = 0
    
    # Transform index data
    for symbol in args.symbols:
        try:
            count = transform_index_bars(
                data_source,
                catalog,
                symbol,
                args.start_date,
                args.end_date
            )
            total_bars += count
        except Exception as e:
            logger.error(f"Error transforming {symbol} index: {e}", exc_info=True)
    
    # Transform futures data
    for symbol in args.symbols:
        try:
            count, _ = transform_futures_bars(  # Returns None now (FutureOI written directly)
                data_source,
                catalog,
                symbol,
                args.start_date,
                args.end_date
            )
            total_bars += count
        except Exception as e:
            logger.error(f"Error transforming {symbol} futures: {e}", exc_info=True)
    
    # Transform options data
    for symbol in args.symbols:
        try:
            count = transform_options_bars(
                data_source,
                catalog,
                symbol,
                args.start_date,
                args.end_date
            )
            total_bars += count
        except Exception as e:
            logger.error(f"Error transforming {symbol} options: {e}", exc_info=True)
    
    # Summary
    print("\n" + "="*80)
    print("TRANSFORMATION COMPLETE")
    print("="*80)
    print(f"Total bars created: {total_bars:,}")
    print(f"Catalog location: {args.output_dir}")
    print("="*80)
    print("\nData structure:")
    print(f"  Bar data: {args.output_dir}/bar/")
    print(f"  FutureOI data: Stored in Nautilus catalog")
    print(f"  Instruments: {args.output_dir}/instrument/")
    print("\nNext steps:")
    print("  1. Verify data: catalog.bars()")
    print("  2. Query FutureOI: catalog.generic_data(FutureOI)")
    print("  3. Run backtest with transformed data")
    print("="*80)


if __name__ == "__main__":
    main()
