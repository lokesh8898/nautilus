# Nautilus Data Transformation - DigitalOcean Spaces Edition

This script transforms NSE market data (index, futures, options) from **DigitalOcean Spaces** (S3-compatible object storage) to **Nautilus Trader Parquet Catalog** format.

## What Changed?

### Original Version
- **Input**: Local filesystem directory (`Path` objects)
- **Output**: Local Nautilus catalog
- **Use case**: Running on local machine with local data

### New Version (DigitalOcean Spaces)
- **Input**: DigitalOcean Spaces bucket (S3-compatible)
- **Output**: Local filesystem (SSH server)
- **Use case**: Running on SSH server, reading data from cloud storage

## Prerequisites

### 1. Python Dependencies

```bash
pip install boto3 pandas pyarrow nautilus_trader
```

### 2. DigitalOcean Spaces Credentials

The script is pre-configured with your credentials:

- **Bucket**: `historical-db-1min`
- **Region**: `blr1` (Bangalore)
- **Endpoint**: `https://blr1.digitaloceanspaces.com`
- **Access Key**: `DO00CDX8Z7BFTQJ9W2AZ`
- **Secret Key**: `kR159s1x7Xjfd6RhVIyw8X34UGLIFKSzP7/0fG6Yt9I`

⚠️ **Security Note**: These credentials are hardcoded for convenience. In production, use environment variables:

```python
access_key=os.getenv("SPACES_ACCESS_KEY"),
secret_key=os.getenv("SPACES_SECRET_KEY")
```

## Usage

### Step 1: Test Connection

First, verify that you can connect to DigitalOcean Spaces:

```bash
python test_spaces_connection.py
```

This will:
- Connect to your Spaces bucket
- List all top-level directories
- Show available data for NIFTY/BANKNIFTY
- Verify the data structure

### Step 2: Run Transformation

Transform data for specific date range and symbols:

```bash
python transform_official_nautilus.py \
    --bucket historical-db-1min \
    --output-dir /root/nautilus_catalog \
    --symbols NIFTY BANKNIFTY \
    --start-date 2024-01-02 \
    --end-date 2024-01-05
```

### Command Line Arguments

| Argument | Default | Description |
|----------|---------|-------------|
| `--bucket` | `historical-db-1min` | DigitalOcean Spaces bucket name |
| `--base-prefix` | `""` (empty) | Base prefix within bucket (e.g., 'nse/data') |
| `--output-dir` | `/root/nautilus_catalog` | Local output directory for catalog |
| `--symbols` | `NIFTY BANKNIFTY` | Space-separated list of symbols |
| `--start-date` | `2024-01-02` | Start date (YYYY-MM-DD) |
| `--end-date` | `2024-01-05` | End date (YYYY-MM-DD) |

### Examples

**Transform single month of NIFTY data:**
```bash
python transform_official_nautilus.py \
    --symbols NIFTY \
    --start-date 2024-01-01 \
    --end-date 2024-01-31 \
    --output-dir /data/nautilus_jan2024
```

**Transform multiple symbols with custom prefix:**
```bash
python transform_official_nautilus.py \
    --bucket historical-db-1min \
    --base-prefix production/data \
    --symbols NIFTY BANKNIFTY FINNIFTY \
    --start-date 2024-01-01 \
    --end-date 2024-12-31
```

## Expected Data Structure in Spaces

The script expects data organized in this structure:

```
historical-db-1min/
├── index/nifty/         # OR cash/nifty/
│   └── *.parquet
├── index/banknifty/     # OR cash/banknifty/
│   └── *.parquet
├── futures/nifty/
│   ├── nifty_future_20240102.parquet
│   ├── nifty_future_20240103.parquet
│   └── ...
├── futures/banknifty/
│   └── *.parquet
├── option/nifty/        # OR options/nifty/
│   ├── nifty_call_20240102.parquet
│   ├── nifty_put_20240102.parquet
│   └── ...
└── option/banknifty/    # OR options/banknifty/
    └── *.parquet
```

### Supported Directory Naming Conventions

The script supports flexible directory naming:

- **Index data**: `index/` or `cash/`
- **Options data**: `option/` or `options/`
- **Options with type suffix**: `option/nifty_call/`, `option/nifty_put/`

## Output Structure

The transformation creates a Nautilus catalog with this structure:

```
/root/nautilus_catalog/
├── bar/
│   ├── NIFTY-INDEX.NSE-1-MINUTE-LAST-EXTERNAL.parquet
│   ├── NIFTY-I.NSE-1-MINUTE-LAST-EXTERNAL.parquet    # Futures
│   └── NIFTY24102CE24500.NSE-1-MINUTE-LAST-EXTERNAL.parquet  # Options
├── quote_tick/
│   └── ... (QuoteTicks for Greeks calculation)
├── custom/
│   ├── FutureOI/
│   │   └── NIFTY-I.NSE.parquet
│   └── OptionOI/
│       └── NIFTY24102CE24500.NSE.parquet
└── instrument/
    └── *.parquet (instrument definitions)
```

## Key Features

### 1. Data Processing
- ✅ Converts date+time to UTC timestamps
- ✅ Handles IST → UTC conversion (−5:30 offset)
- ✅ Normalizes prices from paise to rupees when needed
- ✅ Validates OHLC relationships
- ✅ Generates QuoteTicks for Greeks calculation

### 2. Open Interest (OI)
- ✅ Processes futures OI (FutureOI custom data type)
- ✅ Processes options OI (OptionOI custom data type)
- ✅ Calculates Change in OI (COI)
- ✅ Stored using Arrow serialization

### 3. Instrument Types
- **Index**: Nautilus `Equity` instrument
- **Futures**: Nautilus `FuturesContract` (continuous)
- **Options**: Nautilus `OptionContract` with proper metadata

### 4. Performance
- Streams data directly from Spaces (no local storage needed)
- Processes files incrementally to manage memory
- Skips disjoint data checks for faster writes

## Troubleshooting

### Connection Issues

```
❌ Failed to connect to Spaces: ...
```

**Solution**: Verify credentials and network connectivity:
```bash
# Test with boto3
python -c "import boto3; print(boto3.__version__)"

# Test network
curl https://blr1.digitaloceanspaces.com
```

### No Data Found

```
⚠️ No index/cash directory found for NIFTY
```

**Solution**: 
1. Run `test_spaces_connection.py` to see available directories
2. Check if data uses `index/` or `cash/` prefix
3. Verify symbol name case (should be lowercase in Spaces)

### Date Range Issues

```
⚠️ No data in date range 2024-01-02 to 2024-01-05
```

**Solution**:
- Data is stored in IST but filtered in UTC
- Script automatically applies 6-hour buffer
- Check actual data availability with test script

### Memory Issues

If processing large date ranges:
```bash
# Process in smaller chunks
python transform_official_nautilus.py --start-date 2024-01-01 --end-date 2024-01-31
python transform_official_nautilus.py --start-date 2024-02-01 --end-date 2024-02-28
```

## Architecture Changes

### Before (Local Filesystem)
```python
def transform_index_bars(input_dir: Path, ...):
    parquet_files = list(input_dir.rglob("*.parquet"))
    for file in parquet_files:
        df = pd.read_parquet(file)
```

### After (DigitalOcean Spaces)
```python
def transform_index_bars(data_source: SpacesDataSource, ...):
    parquet_files = data_source.list_parquet_files("index", "nifty")
    for file_key in parquet_files:
        df = data_source.read_parquet(file_key)  # Streams from Spaces
```

### Key Classes

#### `SpacesClient`
Low-level boto3 wrapper for S3 operations:
- `list_directories()` - List "folders" with delimiter
- `list_objects()` - List files with optional suffix filter
- `read_parquet()` - Stream parquet file into DataFrame
- `prefix_exists()` - Check if prefix has any objects

#### `SpacesDataSource`
High-level interface with base prefix support:
- `list_directories(*parts)` - List subdirectories
- `list_parquet_files(*parts)` - Find all .parquet files
- `read_parquet(key)` - Read parquet to DataFrame
- `prefix_exists(*parts)` - Check prefix existence

## Verification

After transformation, verify the data:

```python
from nautilus_trader.persistence.catalog.parquet import ParquetDataCatalog

catalog = ParquetDataCatalog("/root/nautilus_catalog")

# Check instruments
instruments = catalog.instruments()
print(f"Loaded {len(instruments)} instruments")

# Check bars for NIFTY index
bars = catalog.bars(instrument_ids=["NIFTY-INDEX.NSE"])
print(f"NIFTY bars: {len(bars)}")

# Check custom data (FutureOI)
from marvelquant_data.data_types import FutureOI
future_oi = catalog.generic_data(FutureOI, instrument_ids=["NIFTY-I.NSE"])
print(f"Future OI records: {len(future_oi)}")
```

## Next Steps

1. ✅ Test connection with `test_spaces_connection.py`
2. ✅ Transform small date range to verify setup
3. ✅ Verify output with catalog queries
4. ✅ Run full historical transformation
5. ✅ Integrate with backtesting system

## Support

For issues or questions:
1. Check the logs for detailed error messages
2. Verify Spaces bucket structure with test script
3. Ensure all dependencies are installed
4. Check network connectivity to DigitalOcean

---

**Last Updated**: November 10, 2025
**Author**: Modified for DigitalOcean Spaces integration

