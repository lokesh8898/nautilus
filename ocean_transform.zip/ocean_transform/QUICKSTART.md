# Quick Start Guide - DigitalOcean Spaces to Nautilus Transformation

## 🚀 Get Started in 3 Steps

### Step 1: Install Dependencies

```bash
pip install boto3 pandas pyarrow nautilus_trader
```

### Step 2: Test Connection

```bash
python test_spaces_connection.py
```

**Expected output:**
```
================================================================================
DIGITALOCEAN SPACES CONNECTION TEST
================================================================================
Bucket: historical-db-1min
Region: blr1
Endpoint: https://blr1.digitaloceanspaces.com
================================================================================

✅ Client created successfully!

Listing top-level directories...

✅ Found X top-level directories:
  - index/
  - futures/
  - option/
  ...
```

### Step 3: Run Transformation

```bash
python transform_official_nautilus.py \
    --bucket historical-db-1min \
    --output-dir /root/nautilus_catalog \
    --symbols NIFTY BANKNIFTY \
    --start-date 2024-01-02 \
    --end-date 2024-01-05
```

**Expected output:**
```
================================================================================
NAUTILUS DATA TRANSFORMATION - DIGITALOCEAN SPACES
================================================================================
Input: DigitalOcean Spaces bucket 'historical-db-1min'
Output: /root/nautilus_catalog
Symbols: ['NIFTY', 'BANKNIFTY']
Date range: 2024-01-02 to 2024-01-05
================================================================================

Connecting to DigitalOcean Spaces...
Testing connection...
✅ Connected! Found X top-level directories

Transforming NIFTY index bars...
✅ NIFTY: Created 1,250 bars + 1,250 QuoteTicks

Transforming NIFTY futures bars...
✅ NIFTY futures: Created 1,250 bars + 1,250 QuoteTicks
✅ Saved 1,250 FutureOI records

Transforming NIFTY options bars...
✅ NIFTY options: Created 12,500 bars + 12,500 QuoteTicks

[Repeat for BANKNIFTY...]

================================================================================
TRANSFORMATION COMPLETE
================================================================================
Total bars created: 50,000
Catalog location: /root/nautilus_catalog
================================================================================
```

## ✅ Verify Output

```python
from nautilus_trader.persistence.catalog.parquet import ParquetDataCatalog

catalog = ParquetDataCatalog("/root/nautilus_catalog")

# Check instruments
print(f"Instruments: {len(catalog.instruments())}")

# Check NIFTY index bars
bars = catalog.bars(instrument_ids=["NIFTY-INDEX.NSE"])
print(f"NIFTY bars: {len(bars)}")
```

## 📝 Common Commands

### Transform Single Day
```bash
python transform_official_nautilus.py \
    --symbols NIFTY \
    --start-date 2024-01-02 \
    --end-date 2024-01-02
```

### Transform Full Month
```bash
python transform_official_nautilus.py \
    --symbols NIFTY BANKNIFTY \
    --start-date 2024-01-01 \
    --end-date 2024-01-31
```

### Transform Multiple Months (Loop)
```bash
for month in 01 02 03; do
    python transform_official_nautilus.py \
        --symbols NIFTY BANKNIFTY \
        --start-date 2024-${month}-01 \
        --end-date 2024-${month}-31 \
        --output-dir /data/nautilus_2024_q1
done
```

## 🔧 Troubleshooting

### ❌ Connection Failed

```
❌ Failed to connect to Spaces: ...
```

**Solution:**
1. Check internet connection
2. Verify credentials in script
3. Test with: `curl https://blr1.digitaloceanspaces.com`

### ❌ No Data Found

```
⚠️ No index/cash directory found for NIFTY
```

**Solution:**
1. Run `test_spaces_connection.py` to see available directories
2. Check if symbol exists in bucket
3. Verify directory naming (index/ or cash/)

### ❌ Import Error

```
ModuleNotFoundError: No module named 'boto3'
```

**Solution:**
```bash
pip install boto3 pandas pyarrow nautilus_trader
```

### ❌ Memory Error

```
MemoryError: Unable to allocate ...
```

**Solution:** Process smaller date ranges:
```bash
# Instead of full year, do monthly chunks
python transform_official_nautilus.py --start-date 2024-01-01 --end-date 2024-01-31
python transform_official_nautilus.py --start-date 2024-02-01 --end-date 2024-02-28
```

## 📚 More Information

- **Full Documentation**: See `README_SPACES.md`
- **What Changed**: See `CHANGES_SUMMARY.md`
- **Usage Examples**: See `run_examples.sh`

## 🎯 Production Checklist

Before running in production:

- [ ] Test with small date range (2-3 days)
- [ ] Verify output catalog structure
- [ ] Check available disk space for output
- [ ] Monitor memory usage during processing
- [ ] Set up logging to file
- [ ] Consider using environment variables for credentials
- [ ] Plan for incremental updates (process new data only)

## 💡 Pro Tips

1. **Start Small**: Test with 1-2 days before processing months
2. **Monitor Resources**: Watch CPU, memory, and disk usage
3. **Use Screen/Tmux**: For long-running transformations on SSH
4. **Check Logs**: Review warnings for data quality issues
5. **Verify Data**: Always check catalog after transformation

## 🚨 Important Notes

- **Credentials are hardcoded** in the script (line 941-947)
- **Data is streamed** from Spaces (no local caching)
- **Network bandwidth** used for each run
- **Processing time** depends on network speed and data volume

---

**Ready to go!** Start with Step 1 above. 🎉

