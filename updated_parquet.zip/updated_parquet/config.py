################################################################################ importing libraries
from datetime import datetime, time

MISSING_DTS_DIR = "Missing Dates"
LOG_FILE_FOLDER = "Logs"
UPLOAD_DIR = "ParquetOutput"

GDFL_FILES_FOLDER = [
    r"C:\updated_parquet"
]
SPECIAL_CHARACTERS = [
    "-", "&"
]

TODAY = datetime.now()

MYSQL_PASSWORD = "master76"
MYSQL_HOST = "localhost"
MYSQL_USER = "root"

MYSQL_MINUTE_PASSWORD = "master76"
MYSQL_MINUTE_HOST = "192.168.173.180"
MYSQL_MINUTE_USER = "ajay"

# MYSQL_MINUTE_PASSWORD = "master76"
# MYSQL_MINUTE_HOST = "106.51.63.60"
# MYSQL_MINUTE_USER = "ajay"

MARKET_TIMINGS = {
    "NFO": {
        "start": time(9, 15), "end": time(15, 30)
    },
    "BFO": {
        "start": time(9, 15), "end": time(15, 30)
    }
}
VALID_MONTHS = [
    'JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'
]
WORDS_TO_RM = [
    ".NFO", ".BFO", ".MCX"
]
TO_AVOID = [
    'NIFTYIT', 'NIFTYMID50', 'NIFTYCPSE', "SENSEX50", "GOLDGUINEA", "GOLDPETAL", "SILVERMIC", "ZINCMINI"
]
SYMBOL_CHANGE = {
    "SRTRANSFIN": "SHRIRAMFIN", "MCDOWELL_N": "UNITDSPR", "MOTHERSUMI": "MOTHERSON", "L_TFH": "LTF", "CADILAHC": "ZYDUSLIFE", "PVR": "PVRINOX", "LTI": "LTIM"
}