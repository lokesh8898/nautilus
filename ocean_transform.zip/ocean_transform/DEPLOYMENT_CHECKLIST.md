# Deployment Checklist

## 📦 Files Ready for Deployment

### Modified Files
- ✅ `transform_official_nautilus.py` - Main transformation script (modified for Spaces)

### New Files Created
- ✅ `test_spaces_connection.py` - Connection test utility
- ✅ `README_SPACES.md` - Complete documentation
- ✅ `QUICKSTART.md` - Quick start guide
- ✅ `CHANGES_SUMMARY.md` - Detailed change log
- ✅ `run_examples.sh` - Usage examples
- ✅ `DEPLOYMENT_CHECKLIST.md` - This file

## 🚀 Deployment Steps

### 1. Copy Files to SSH Server

```bash
# Replace 'your-server' with actual SSH address
scp transform_official_nautilus.py maruth@your-server:/root/
scp test_spaces_connection.py maruth@your-server:/root/
scp README_SPACES.md maruth@your-server:/root/
scp QUICKSTART.md maruth@your-server:/root/
scp run_examples.sh maruth@your-server:/root/
```

### 2. SSH into Server

```bash
ssh maruth@your-server
cd /root
```

### 3. Install Python Dependencies

```bash
pip install boto3 pandas pyarrow nautilus_trader
```

**Or with requirements file:**

```bash
# Create requirements.txt
cat > requirements.txt << EOF
boto3>=1.26.0
pandas>=2.0.0
pyarrow>=12.0.0
nautilus_trader>=1.196.0
EOF

pip install -r requirements.txt
```

### 4. Test Connection

```bash
python test_spaces_connection.py
```

**Expected Result:** Should list directories in Spaces bucket

### 5. Test with Small Date Range

```bash
python transform_official_nautilus.py \
    --bucket historical-db-1min \
    --output-dir /root/nautilus_catalog_test \
    --symbols NIFTY \
    --start-date 2024-01-02 \
    --end-date 2024-01-02
```

**Expected Result:** Should create ~375 bars for 1 trading day

### 6. Verify Output

```bash
ls -lah /root/nautilus_catalog_test/

# Should show:
# - bar/
# - quote_tick/
# - custom/
# - instrument/
```

### 7. Run Production Transformation

```bash
# For full month
python transform_official_nautilus.py \
    --bucket historical-db-1min \
    --output-dir /root/nautilus_catalog \
    --symbols NIFTY BANKNIFTY \
    --start-date 2024-01-01 \
    --end-date 2024-01-31
```

**For Long-Running Jobs:**

```bash
# Use screen or tmux
screen -S nautilus_transform

python transform_official_nautilus.py \
    --bucket historical-db-1min \
    --output-dir /root/nautilus_catalog \
    --symbols NIFTY BANKNIFTY \
    --start-date 2024-01-01 \
    --end-date 2024-12-31

# Detach: Ctrl+A then D
# Reattach: screen -r nautilus_transform
```

## ✅ Pre-Flight Checks

Before production run:

- [ ] SSH server has sufficient disk space
  ```bash
  df -h /root
  ```

- [ ] Python 3.9+ is installed
  ```bash
  python --version
  ```

- [ ] Required packages are installed
  ```bash
  pip list | grep -E 'boto3|pandas|pyarrow|nautilus'
  ```

- [ ] Network connectivity to Spaces
  ```bash
  curl -I https://blr1.digitaloceanspaces.com
  ```

- [ ] Test connection succeeds
  ```bash
  python test_spaces_connection.py
  ```

- [ ] Output directory exists or can be created
  ```bash
  mkdir -p /root/nautilus_catalog
  ```

## 🔍 Post-Deployment Verification

### 1. Check File Counts

```bash
find /root/nautilus_catalog -name "*.parquet" | wc -l
```

**Expected:** Hundreds to thousands of parquet files depending on date range

### 2. Check Disk Usage

```bash
du -sh /root/nautilus_catalog
```

**Expected:** 
- 1 day: ~500MB - 2GB
- 1 month: ~15GB - 50GB
- 1 year: ~180GB - 600GB

### 3. Verify with Python

```python
from nautilus_trader.persistence.catalog.parquet import ParquetDataCatalog

catalog = ParquetDataCatalog("/root/nautilus_catalog")

# Check instruments
instruments = catalog.instruments()
print(f"Total instruments: {len(instruments)}")

# Check index bars
nifty_bars = catalog.bars(instrument_ids=["NIFTY-INDEX.NSE"])
print(f"NIFTY bars: {len(nifty_bars)}")

# Check futures
nifty_future_bars = catalog.bars(instrument_ids=["NIFTY-I.NSE"])
print(f"NIFTY futures bars: {len(nifty_future_bars)}")

# Check custom data
from marvelquant_data.data_types import FutureOI
future_oi = catalog.generic_data(FutureOI, instrument_ids=["NIFTY-I.NSE"])
print(f"NIFTY FutureOI records: {len(future_oi)}")
```

### 4. Check for Warnings

```bash
grep "WARNING" /var/log/nautilus_transform.log  # If logging to file
```

## 📊 Performance Estimates

### Network Transfer (from Spaces)

| Date Range | Data Volume | Transfer Time (10 Mbps) |
|------------|-------------|-------------------------|
| 1 day      | ~200MB      | ~3 minutes             |
| 1 week     | ~1.4GB      | ~20 minutes            |
| 1 month    | ~6GB        | ~80 minutes            |
| 1 year     | ~70GB       | ~16 hours              |

### Processing Time (After Download)

| Date Range | Processing Time |
|------------|-----------------|
| 1 day      | ~2-5 minutes    |
| 1 week     | ~15-30 minutes  |
| 1 month    | ~1-2 hours      |
| 1 year     | ~12-24 hours    |

**Note:** Times vary based on:
- Network speed
- Server CPU/RAM
- Number of symbols
- Options data volume

## 🔧 Troubleshooting

### Issue: Import Error for marvelquant_data

```python
ModuleNotFoundError: No module named 'marvelquant_data'
```

**Solution:** Ensure custom data types are in Python path:

```bash
# Option 1: Install as package
cd /path/to/marvelquant_data
pip install -e .

# Option 2: Add to PYTHONPATH
export PYTHONPATH=$PYTHONPATH:/path/to/marvelquant_data
```

### Issue: Connection Timeout

```
botocore.exceptions.ConnectTimeoutError
```

**Solution:**
1. Check firewall rules
2. Verify DNS resolution: `nslookup blr1.digitaloceanspaces.com`
3. Test with curl: `curl https://blr1.digitaloceanspaces.com`

### Issue: Out of Memory

```
MemoryError: Unable to allocate ...
```

**Solution:** Process in smaller chunks:

```bash
# Monthly chunks instead of yearly
for month in {01..12}; do
    python transform_official_nautilus.py \
        --start-date 2024-${month}-01 \
        --end-date 2024-${month}-31
done
```

### Issue: Slow Processing

**Optimization tips:**
1. Use SSD for output directory
2. Increase network bandwidth
3. Process fewer symbols per run
4. Skip options data if not needed:
   - Comment out `transform_options_bars()` calls

## 📝 Monitoring

### Monitor Disk Space

```bash
watch -n 60 'df -h /root && du -sh /root/nautilus_catalog'
```

### Monitor Network Usage

```bash
sudo iftop -i eth0
```

### Monitor Process

```bash
top -p $(pgrep -f transform_official_nautilus.py)
```

### Log to File

```bash
python transform_official_nautilus.py \
    --bucket historical-db-1min \
    --output-dir /root/nautilus_catalog \
    --symbols NIFTY BANKNIFTY \
    --start-date 2024-01-01 \
    --end-date 2024-12-31 \
    2>&1 | tee transform_$(date +%Y%m%d).log
```

## 🎯 Production Best Practices

1. **Incremental Processing**
   - Process data in monthly chunks
   - Store monthly catalogs separately
   - Merge later if needed

2. **Backup Strategy**
   - Keep raw data in Spaces (already done)
   - Backup processed catalog periodically
   - Test restore procedures

3. **Error Handling**
   - Monitor logs for warnings
   - Set up alerts for failures
   - Keep track of processed date ranges

4. **Security**
   - Use environment variables for credentials
   - Restrict access to output directory
   - Rotate access keys periodically

5. **Documentation**
   - Document processed date ranges
   - Note any data quality issues
   - Keep transformation parameters recorded

## 📞 Support Checklist

If issues arise:

- [ ] Check `README_SPACES.md` for troubleshooting
- [ ] Review logs for error messages
- [ ] Verify test connection still works
- [ ] Check disk space and memory
- [ ] Try with smaller date range
- [ ] Verify credentials haven't expired

## ✨ Success Criteria

Deployment is successful when:

- ✅ Test connection succeeds
- ✅ Small date range transforms successfully
- ✅ Output catalog structure is correct
- ✅ Data can be queried with Nautilus catalog
- ✅ OI data is present for futures/options
- ✅ No critical errors in logs
- ✅ Backtest can load data successfully

---

**Last Updated:** November 10, 2025  
**Status:** Ready for deployment 🚀

