#!/usr/bin/env python3
"""
Check Available Data in DigitalOcean Spaces

Lists all available data in DigitalOcean Spaces bucket and exports to CSV.

Configuration:
- Endpoint: https://blr1.digitaloceanspaces.com
- Space: historical-db-tick
- Region: blr1 (Bangalore)
- Access via S3-compatible API
- Credentials: Built-in (hardcoded)

Output CSV Columns:
- file_key: Full S3 key/path
- file_name: Just the filename
- size_bytes: File size in bytes
- size_mb: File size in MB
- last_modified: Last modification timestamp
- category: Category (cash/options/futures)
- symbol: Symbol name
- year: Year from path
- month: Month from path
- storage_class: Storage class

Usage:
    # Check all data in bucket
    python check_digitalocean_spaces.py
    
    # Check specific path/prefix
    python check_digitalocean_spaces.py --prefix raw/parquet_data/cash
    
    # Check specific symbols
    python check_digitalocean_spaces.py --symbols banknifty nifty
    
    # Specify output CSV file
    python check_digitalocean_spaces.py --output my_inventory.csv
    
    # Include summary statistics
    python check_digitalocean_spaces.py --stats

Author: MarvelQuant
Date: 2025-10-30
"""

import os
import sys
import boto3
import logging
import argparse
import csv
from pathlib import Path
from typing import List, Dict
from datetime import datetime
from collections import defaultdict
from botocore.exceptions import ClientError

# Logging configuration
def setup_logging():
    """Setup logging with cross-platform log file path"""
    log_file = Path('./digitalocean_check.log')
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

logger = setup_logging()

# DigitalOcean Spaces configuration
DO_ENDPOINT = "https://blr1.digitaloceanspaces.com"
DO_REGION = "blr1"
SPACE_NAME = "historical-db-tick"
SPACE_PREFIX = "raw/parquet_data"


class DigitalOceanSpacesChecker:
    """Check available data in DigitalOcean Spaces"""

    def __init__(
        self,
        prefix: str = None,
        symbols: List[str] = None,
        output_file: str = "digitalocean_inventory.csv",
        show_files: bool = True
    ):
        self.prefix = prefix or SPACE_PREFIX
        self.symbols = symbols
        self.output_file = output_file
        self.show_files = show_files

        # Hardcoded credentials
        self.access_key = "DO00CDX8Z7BFTQJ9W2AZ"
        self.secret_key = "kR159s1x7Xjfd6RhVIyw8X34UGLIFKSzP7/0fG6Yt9I"

        # Initialize S3 client
        self.s3_client = boto3.client(
            's3',
            region_name=DO_REGION,
            endpoint_url=DO_ENDPOINT,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key
        )

        # Stats
        self.stats = {
            'total_files': 0,
            'total_bytes': 0,
            'by_category': defaultdict(lambda: defaultdict(lambda: {'files': 0, 'bytes': 0})),
            'by_year': defaultdict(lambda: {'files': 0, 'bytes': 0}),
            'by_extension': defaultdict(lambda: {'files': 0, 'bytes': 0})
        }

    def verify_space_exists(self) -> bool:
        """Verify that the Space exists"""
        try:
            self.s3_client.head_bucket(Bucket=SPACE_NAME)
            logger.info(f"[OK] Space '{SPACE_NAME}' exists and is accessible")
            return True
        except ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code == '404':
                logger.error(f"[ERROR] Space '{SPACE_NAME}' does not exist")
            elif error_code == '403':
                logger.error(f"[ERROR] Access denied to Space '{SPACE_NAME}'")
            else:
                logger.error(f"[ERROR] Error accessing Space: {e}")
            return False

    def parse_s3_key(self, key: str) -> Dict[str, str]:
        """Parse S3 key to extract metadata"""
        # Expected structure: raw/parquet_data/category/symbol/YYYY/MM/filename.parquet
        parts = key.split('/')
        
        metadata = {
            'file_key': key,
            'file_name': parts[-1] if parts else '',
            'category': '',
            'symbol': '',
            'year': '',
            'month': '',
            'extension': ''
        }
        
        # Extract extension
        if '.' in metadata['file_name']:
            metadata['extension'] = metadata['file_name'].split('.')[-1]
        
        # Try to parse structured path: raw/parquet_data/category/symbol/YYYY/MM/filename
        if len(parts) >= 6:
            if parts[0] == 'raw' and parts[1] == 'parquet_data':
                metadata['category'] = parts[2]  # cash/options/futures
                metadata['symbol'] = parts[3]    # banknifty, nifty_call, etc.
                metadata['year'] = parts[4]      # YYYY
                metadata['month'] = parts[5]     # MM
        
        return metadata

    def list_all_objects(self, show_files: bool = True) -> List[Dict]:
        """List all objects in the bucket with given prefix"""
        logger.info(f"[LISTING] Listing objects in bucket '{SPACE_NAME}' with prefix '{self.prefix}'...")
        logger.info("")
        
        all_objects = []
        continuation_token = None
        page_count = 0
        
        try:
            while True:
                page_count += 1
                
                # Prepare list_objects_v2 parameters
                params = {
                    'Bucket': SPACE_NAME,
                    'Prefix': self.prefix
                }
                
                if continuation_token:
                    params['ContinuationToken'] = continuation_token
                
                # List objects
                response = self.s3_client.list_objects_v2(**params)
                
                # Process objects
                if 'Contents' in response:
                    page_objects = response['Contents']
                    all_objects.extend(page_objects)
                    
                    logger.info(f"[PAGE {page_count}] Found {len(page_objects)} objects "
                              f"(Total so far: {len(all_objects)})")
                    
                    # Display file names if requested
                    if show_files:
                        for obj in page_objects:
                            key = obj['Key']
                            size_mb = obj['Size'] / (1024 * 1024)
                            last_modified = obj['LastModified'].strftime('%Y-%m-%d %H:%M:%S')
                            logger.info(f"   -> {key} ({size_mb:.2f} MB, {last_modified})")
                        logger.info("")  # Empty line for readability
                
                # Check if there are more pages
                if response.get('IsTruncated', False):
                    continuation_token = response.get('NextContinuationToken')
                else:
                    break
            
            logger.info(f"[OK] Total objects found: {len(all_objects)}")
            return all_objects
            
        except ClientError as e:
            logger.error(f"[ERROR] Error listing objects: {e}")
            return []

    def filter_objects(self, objects: List[Dict]) -> List[Dict]:
        """Filter objects based on symbols if specified"""
        if not self.symbols:
            return objects
        
        logger.info(f"[FILTER] Filtering objects for symbols: {', '.join(self.symbols)}")
        
        filtered = []
        for obj in objects:
            key = obj['Key']
            metadata = self.parse_s3_key(key)
            
            # Check if symbol matches
            symbol_base = metadata['symbol'].split('_')[0]  # Handle nifty_call -> nifty
            if symbol_base in self.symbols:
                filtered.append(obj)
        
        logger.info(f"[OK] Filtered to {len(filtered)} objects")
        return filtered

    def export_to_csv(self, objects: List[Dict]):
        """Export object list to CSV file"""
        logger.info(f"[CSV] Exporting {len(objects)} objects to CSV: {self.output_file}")
        
        if not objects:
            logger.warning("[WARNING] No objects to export!")
            return
        
        csv_headers = [
            'file_key',
            'file_name',
            'size_bytes',
            'size_mb',
            'size_gb',
            'last_modified',
            'category',
            'symbol',
            'year',
            'month',
            'extension',
            'storage_class',
            'etag'
        ]
        
        try:
            with open(self.output_file, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=csv_headers)
                writer.writeheader()
                
                for obj in objects:
                    key = obj['Key']
                    size = obj['Size']
                    last_modified = obj['LastModified'].strftime('%Y-%m-%d %H:%M:%S')
                    
                    # Parse metadata from key
                    metadata = self.parse_s3_key(key)
                    
                    # Update stats
                    self.stats['total_files'] += 1
                    self.stats['total_bytes'] += size
                    
                    category = metadata['category']
                    symbol = metadata['symbol']
                    year = metadata['year']
                    extension = metadata['extension']
                    
                    if category and symbol:
                        self.stats['by_category'][category][symbol]['files'] += 1
                        self.stats['by_category'][category][symbol]['bytes'] += size
                    
                    if year:
                        self.stats['by_year'][year]['files'] += 1
                        self.stats['by_year'][year]['bytes'] += size
                    
                    if extension:
                        self.stats['by_extension'][extension]['files'] += 1
                        self.stats['by_extension'][extension]['bytes'] += size
                    
                    # Write row
                    row = {
                        'file_key': key,
                        'file_name': metadata['file_name'],
                        'size_bytes': size,
                        'size_mb': round(size / (1024 * 1024), 2),
                        'size_gb': round(size / (1024 * 1024 * 1024), 4),
                        'last_modified': last_modified,
                        'category': category,
                        'symbol': symbol,
                        'year': year,
                        'month': month,
                        'extension': extension,
                        'storage_class': obj.get('StorageClass', 'STANDARD'),
                        'etag': obj.get('ETag', '').strip('"')
                    }
                    
                    writer.writerow(row)
            
            logger.info(f"[OK] CSV exported successfully: {self.output_file}")
            
        except Exception as e:
            logger.error(f"[ERROR] Error exporting CSV: {e}")

    def print_file_list(self, objects: List[Dict]):
        """Print a clean list of all files"""
        logger.info("\n" + "=" * 100)
        logger.info("FILE LIST - ALL AVAILABLE FILES")
        logger.info("=" * 100)
        logger.info(f"\nTotal Files: {len(objects)}\n")
        
        for idx, obj in enumerate(objects, 1):
            key = obj['Key']
            size_mb = obj['Size'] / (1024 * 1024)
            last_modified = obj['LastModified'].strftime('%Y-%m-%d %H:%M:%S')
            
            # Extract just the filename for cleaner display
            filename = key.split('/')[-1]
            
            logger.info(f"{idx:6d}. {filename}")
            logger.info(f"        Path: {key}")
            logger.info(f"        Size: {size_mb:.2f} MB | Modified: {last_modified}")
            logger.info("")
        
        logger.info("=" * 100)

    def print_statistics(self):
        """Print detailed statistics"""
        logger.info("\n" + "=" * 100)
        logger.info("INVENTORY STATISTICS")
        logger.info("=" * 100)
        
        # Overall stats
        logger.info(f"\n[STATS] Overall Statistics:")
        logger.info(f"  Total files:       {self.stats['total_files']:,}")
        logger.info(f"  Total size:        {self.stats['total_bytes'] / (1024**3):.2f} GB")
        
        if self.stats['total_files'] > 0:
            avg_size = self.stats['total_bytes'] / self.stats['total_files']
            logger.info(f"  Average file size: {avg_size / (1024 * 1024):.2f} MB")
        
        # By category
        if self.stats['by_category']:
            logger.info(f"\n[STATS] By Category & Symbol:")
            for category in sorted(self.stats['by_category'].keys()):
                logger.info(f"\n  {category.upper()}:")
                for symbol in sorted(self.stats['by_category'][category].keys()):
                    stats = self.stats['by_category'][category][symbol]
                    size_gb = stats['bytes'] / (1024 * 1024 * 1024)
                    logger.info(f"    {symbol:25s}: {stats['files']:8,} files | {size_gb:10.2f} GB")
        
        # By year
        if self.stats['by_year']:
            logger.info(f"\n[STATS] By Year:")
            for year in sorted(self.stats['by_year'].keys()):
                stats = self.stats['by_year'][year]
                size_gb = stats['bytes'] / (1024 * 1024 * 1024)
                logger.info(f"  {year}: {stats['files']:8,} files | {size_gb:10.2f} GB")
        
        # By extension
        if self.stats['by_extension']:
            logger.info(f"\n[STATS] By File Extension:")
            for ext in sorted(self.stats['by_extension'].keys()):
                stats = self.stats['by_extension'][ext]
                size_gb = stats['bytes'] / (1024 * 1024 * 1024)
                logger.info(f"  .{ext}: {stats['files']:8,} files | {size_gb:10.2f} GB")
        
        logger.info("\n" + "=" * 100)

    def run(self, show_stats: bool = True):
        """Execute inventory check"""
        logger.info("=" * 100)
        logger.info("DIGITALOCEAN SPACES INVENTORY CHECK")
        logger.info("=" * 100)
        logger.info(f"Endpoint: {DO_ENDPOINT}")
        logger.info(f"Space: {SPACE_NAME}")
        logger.info(f"Region: {DO_REGION}")
        logger.info(f"Prefix: {self.prefix}")
        if self.symbols:
            logger.info(f"Symbols filter: {', '.join(self.symbols)}")
        logger.info(f"Output CSV: {self.output_file}")
        logger.info(f"Show file names: {self.show_files}")
        logger.info("=" * 100 + "\n")

        # Verify Space exists
        if not self.verify_space_exists():
            logger.error("Cannot proceed without accessible Space")
            return

        # List all objects
        objects = self.list_all_objects(show_files=self.show_files)

        if not objects:
            logger.warning("[WARNING] No objects found in the specified path!")
            return

        # Filter by symbols if specified
        if self.symbols:
            objects = self.filter_objects(objects)
        
        if not objects:
            logger.warning("[WARNING] No objects remaining after filtering!")
            return

        # Export to CSV
        self.export_to_csv(objects)

        # Print file list if not shown during listing
        if not self.show_files:
            self.print_file_list(objects)

        # Print statistics
        if show_stats:
            self.print_statistics()

        logger.info(f"\n[COMPLETE] Inventory check complete! Results saved to: {self.output_file}")


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Check available data in DigitalOcean Spaces and export to CSV"
    )
    parser.add_argument(
        '--prefix',
        type=str,
        default=None,
        help=f'S3 prefix/path to check (default: {SPACE_PREFIX})'
    )
    parser.add_argument(
        '--symbols',
        nargs='+',
        help='Filter by specific symbols (e.g., banknifty nifty)'
    )
    parser.add_argument(
        '--output',
        type=str,
        default='digitalocean_inventory.csv',
        help='Output CSV filename (default: digitalocean_inventory.csv)'
    )
    parser.add_argument(
        '--stats',
        action='store_true',
        default=True,
        help='Show statistics summary (default: True)'
    )
    parser.add_argument(
        '--no-stats',
        action='store_true',
        help='Hide statistics summary'
    )
    parser.add_argument(
        '--no-files',
        action='store_true',
        help='Hide file names during listing (only show summary)'
    )

    args = parser.parse_args()

    # Interactive path input if not provided via command-line
    prefix = args.prefix
    if prefix is None:
        # Define menu options
        menu_options = {
            '1': SPACE_PREFIX,
            '2': f"{SPACE_PREFIX}/cash",
            '3': f"{SPACE_PREFIX}/options",
            '4': f"{SPACE_PREFIX}/futures",
            '5': f"{SPACE_PREFIX}/cash/banknifty"
        }
        
        print("=" * 80)
        print("DIGITALOCEAN SPACES PATH CHECKER")
        print("=" * 80)
        print(f"\nDefault path: {SPACE_PREFIX}")
        print("\nCommon paths:")
        print(f"  1. {SPACE_PREFIX}                    (All data)")
        print(f"  2. {SPACE_PREFIX}/cash               (Cash segment only)")
        print(f"  3. {SPACE_PREFIX}/options            (Options segment only)")
        print(f"  4. {SPACE_PREFIX}/futures            (Futures segment only)")
        print(f"  5. {SPACE_PREFIX}/cash/banknifty     (Specific symbol in cash)")
        print("\nYou can enter a number (1-5) or any custom path.")
        print("-" * 80)
        
        user_input = input(f"\nEnter choice or path (press Enter for default): ").strip()
        
        if not user_input:
            # Empty input - use default
            prefix = SPACE_PREFIX
            logger.info(f"Using default path: {prefix}")
        elif user_input in menu_options:
            # Menu selection
            prefix = menu_options[user_input]
            logger.info(f"Selected option {user_input}: {prefix}")
        else:
            # Custom path
            prefix = user_input
            logger.info(f"Using custom path: {prefix}")
        
        print()  # Empty line for better readability

    # Determine whether to show stats and files
    show_stats = args.stats and not args.no_stats
    show_files = not args.no_files

    # Create checker
    try:
        checker = DigitalOceanSpacesChecker(
            prefix=prefix,
            symbols=args.symbols,
            output_file=args.output,
            show_files=show_files
        )

        # Run
        checker.run(show_stats=show_stats)

    except KeyboardInterrupt:
        logger.warning("\n[WARNING] Check interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"\n[ERROR] Check failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()

